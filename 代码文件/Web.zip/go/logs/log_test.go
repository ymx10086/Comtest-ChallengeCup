package logs

import (
	"testing"
)

func TestLog(t *testing.T) {
	InitLog()
}
