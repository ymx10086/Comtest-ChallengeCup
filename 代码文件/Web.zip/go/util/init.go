package util

// 显式初始化
func Init() {
	initIDGen()
}
