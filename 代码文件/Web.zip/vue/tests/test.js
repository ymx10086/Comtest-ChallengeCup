//
// export const test = async function () {
//     try {
//         let value = await abc(undefined);
//         console.log(value)
//     } catch (e) {
//         console.log(e.toString())
//     }
// }
//
//
// async function abc(value) {
//     if (value === undefined) {
//         await Promise.reject(new Error("test error"))
//     } else {
//         return value
//     }
// }
// 如果我定义一个promise对象，那么revolve的结果能够直接作为return的值

import {getRandomBytes} from "@/utils/ByteUtils";
import forge from 'node-forge'
// import {arrayBufferToBase64} from "@/utils/StringUtils";
// import {decryptByAES256, encryptByAES256} from "@/utils/EncryptUtils";
import crypto from 'crypto'
import {arrayBufferToBase64, base64ToArrayBuffer, stringToArrayBuffer} from "@/utils/StringUtils";
import CryptoJS from "crypto-js";
import {pingTest} from "@/request/file";
import {getRandomFile} from "@/utils/FileUtils";
export function main() {
    for (let i = 1; i <= 20; i++) {
        let totalEnc = 0;
        let totalDec = 0;
        for (let j = 0; j < 20; j++) {
            let file = stringToArrayBuffer(getRandomFile(i* 1024 * 1024));
            let fileSecret = getRandomBytes(32);
            // let a = Date.now()
            let encryptedMSG = encryptByAES256(file, fileSecret, "0123456789012345")
            // Encrypt(arrayBufferToBase64(file), arrayBufferToBase64(fileSecret))
            // console.log(Date.now() - a)
            totalEnc += encryptedMSG[0];
            totalDec += encryptedMSG[1];
        }
        console.log("enc", i, totalEnc / 20);
        console.log("dec", i, totalDec / 20)
    }
}
function encryptByAES256(msg, secretKey, iv){
    //明文参数
    let str = CryptoJS.enc.Base64.parse(arrayBufferToBase64(msg)); // 这里为了和Android对接，不能使用utf8
    let key = CryptoJS.enc.Base64.parse(arrayBufferToBase64(secretKey));
    let IV = CryptoJS.enc.Utf8.parse(iv)
    //加密
    let a = Date.now()
    let encryptedData = CryptoJS.AES.encrypt(str, key, {
        iv:IV,
        mode: CryptoJS.mode.CBC, //AES加密模式
        padding: CryptoJS.pad.Pkcs7 //填充方式
    });
    let encCost = Date.now() - a
    // console.log("加密后："+encryptedData);
    let encAB = base64ToArrayBuffer(CryptoJS.enc.Base64.stringify(encryptedData.ciphertext)); //返回base64格式密文
    let decTime = decryptByAES256(encAB, secretKey, iv);
    return [encCost, decTime]
}

function decryptByAES256(msg, secretKey, iv){
    //base64格式密文转换
    let base64 = CryptoJS.enc.Base64.parse(arrayBufferToBase64(msg))
    let str = CryptoJS.enc.Base64.stringify(base64)
    let key = CryptoJS.enc.Base64.parse(arrayBufferToBase64(secretKey))
    let IV = CryptoJS.enc.Utf8.parse(iv)
    //解密
    let a = Date.now();
    CryptoJS.AES.decrypt(str, key, {
        iv:IV,
        mode: CryptoJS.mode.CBC, //AES加密模式
        padding: CryptoJS.pad.Pkcs7 //填充方式
    });
    return Date.now() - a;
    // return stringToArrayBuffer(CryptoJS.enc.Utf8.stringify(decryptedData).toString());
}
// main()

export async function ping() {
    let total = 0;
    for (let i = 0; i < 10; i++) {
        let a = Date.now();
        await pingTest()
        total += Date.now() - a;
    }
    console.log("ping10000", total / 10);
}

export async function testPro() {
    const promise1 = Promise.resolve(3);
    const promise2 = [42, 1];
    const promise3 = new Promise((resolve, reject) => {
        setTimeout(resolve, 100, 'foo');
    });

    let a = await Promise.all([promise1, promise2, promise3])

    console.log(a)
// Expected output: Array [3, 42, "foo"]

}