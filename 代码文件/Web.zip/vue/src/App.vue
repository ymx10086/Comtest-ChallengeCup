<template>
    <div id="app">
        <Header v-if="isHeaderShow" id="headWrapper"></Header>
        <keep-alive>
            <router-view class="mainContent"></router-view>
        </keep-alive>
<!--        <Footer v-if="isFooterShow"></Footer>-->

        <!-- 将上传组件全局注册 -->

    </div>
</template>

<script>
import Header from '@/components/Header.vue'
import {main, ping, testPro} from "../tests/test";
import {getRandomFile} from "@/utils/FileUtils";

export default {
    name: 'App',
    components: {
        Header,
        // Footer,
    },
    computed: {
        //  头部是否显示
        isHeaderShow() {
            // main()
            // ping()
            // console.log(getRandomFile(1024))
            // testPro()
            let routerNameList = ['Error_401', 'Error_404', 'Error_500']
            return !routerNameList.includes(this.$route.name);
        },
    },
    data() {
        return {}
    },
}
</script>
<style lang="stylus" scoped>
@import '~@/assets/styles/varibles.styl'
#app
  height 100%
  overflow-x hidden
  -webkit-text-size-adjust none
  overflow-y auto

  >>> .el-backtop
    background-color $Success
    color #fff
    z-index 3

  .mainContent
    flex 1
    width 90%
    min-height calc(100vh - 70px)
    margin 0 auto
    display flex
</style>
