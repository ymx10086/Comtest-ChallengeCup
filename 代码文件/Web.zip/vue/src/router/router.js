import Router from 'vue-router'
import Vue from 'vue'
import {ROOT_PATH, FILE_TYPE, SYSTEM_NAME} from "@/global/globalConst";

Vue.use(Router)
export default new Router({
    mode: 'history',
    base: process.env.BASE_URL,
    routes: [
        {
            path: '/',
            name: 'Home',
            redirect: {path: '/file', query: {fileType: FILE_TYPE.ALL, pid: ROOT_PATH}}
        }, {
            path: '/login',
            name: 'Login',
            component: () => import('@/views/user/Login.vue'),
            meta: {title: '登录 - ' + SYSTEM_NAME},
        }, {
            path: '/register',
            name: 'Register',
            component: () => import('@/views/user/Register.vue'),
            meta: {title: '注册 - ' + SYSTEM_NAME},
        }, {
            path: '/file',
            name: 'File',
            component: () => import('@/views/file/File.vue'),
            meta: {
                requireAuth: true,
                title: SYSTEM_NAME,
                keepAlive: false,
                content: {
                    description: '密态网盘'
                }
            }
        }
    ]
})


const originalPush = Router.prototype.push;
Router.prototype.push = function push(location) {
    return originalPush.call(this, location).catch(err => err)
};
