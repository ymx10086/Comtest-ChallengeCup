//  文件模块接口
import {post} from './http'

/**
 * 查询文件相关api
 */
export function getDir(data = {}) {
    return post('/dir/get', data)
}

export function searchFile(data = {}) {
    return post('/file/search', data)
}

export function getNodeId(data = {}) {
    return post('/node/getId', data)
}

export function uploadFile(data = {}) {
    return post('/file/upload', data)
}
export function createDir(data = {}) {
    return post("/dir/create", data)
}

export function getNodeRemote(data = {}) {
    return post("/node/get", data)
}

export function sendSearchToken(data = {}) {
    return post("/file/sendSearchToken", data)
}

export function deleteFile(data = {}) {
    return post("/node/delete", data)
}

export function uploadShareToken(data = {}) {
    return post("/file/uploadShareToken", data)
}

export function getShareTokens(data = {}) {
    return post("/file/getShareTokens", data)
}

export function shareFirstWithServer(data= {}) {
    return post("/file/shareFirst", data)
}

export function shareSecondWithServer(data={}) {
    return post("/file/shareSecond", data)
}

export function deleteShareToken(data = {}) {
    return post("/node/shareToken", data)
}

export function pingTest(data={}) {
    return post("/ping", data)
}