/**
 * post请求，formData格式，不传额外info参数,调用接口时，test({key: value}).then(res => {})
 * export const test = p => post('/user/getattentionstate', p);
 *
 * post请求，非formData格式，传递额外info = true参数，调用接口时，test({key: value},true).then(res => {})
 * export const test = (p, info) => post('/user/getattentionstate', p, info);
 *
 * 目前所有post接口均采用formData格式
 */

//  和用户信息相关的接口
import { post } from './http'

export function login(data = {}) {
   return post('/user/login',data)
}
// 获取登录用户信息
export function addUser(data = {}) {
   return post('/user/register',data )
}
export function changePassword(data = {}) {
   return post("/user/changePwd", data)
}

