import {url} from "@/request/http";
import {biIndexDeserialize, mapDeserialize, mapSerialize, mapsSerialize} from "@/utils/JSON";

export default {
    namespaced: true,
    state: {
        isLogin: false, //初始时候给一个 isLogin = false 表示用户未登录
        user: sessionStorage.getItem("user") || {
            username: '',
            imgUrl: '',
            email: '',
        },
        biIndex: { // 存的是两个JSON字符串
            lastW: "",
            lastID: ""
        },
        error: 0,
    },
    getters: {
        getLastW: state => {
            return mapDeserialize(state.biIndex.lastW);
        },
        getLastId: state => {
            return mapDeserialize(state.biIndex.lastID);
        },
        getBiIndex: state => {
            let lastW = mapDeserialize(state.biIndex.lastW)
            let lastID = mapDeserialize(state.biIndex.lastID)
            return mapsSerialize(lastID, lastW)
        }
    },
    mutations: {
        setUserLogin(state, loginUser) {
            let imgUrl = loginUser.imgUrl;
            state.isLogin = true;
            if (imgUrl) {
                imgUrl = url('/transfer/thumbnail/' + imgUrl)
            } else {
                // 没有头像，显示的默认头像
                imgUrl = "@/assets/images/settings/use.png";
            }
            loginUser.imgUrl = imgUrl
            state.user = loginUser
            sessionStorage.setItem("user", loginUser);
        }
        ,
        setUserLogout(state) {
            sessionStorage.removeItem("user")
            state.isLogin = false
            state.user = {
                username: '',
                imgUrl: '',
                email: '',
            }
        },
        setLastW(state, value) {
            state.biIndex.lastW = value
        },
        setLastID(state, value) {
            state.biIndex.lastID = value
        }
    }
    ,
    actions: {
        setBiIndex(context, value) {
            let biIndex = biIndexDeserialize(value);
            let lastID = mapSerialize(biIndex[0])
            let lastW = mapSerialize(biIndex[1])
            context.commit("setLastID", lastID)
            // console.log("MapLastId", biIndex[0])
            // console.log("MapLastW", biIndex[1])
            // console.log("StringLastID", lastID)
            // console.log("StringLastW",lastW)
            context.commit("setLastW", lastW)
        }
        ,
        addInLastID(context, value) {
            let map = mapDeserialize(context.state.biIndex.lastID)
            map.set(value[0], value[1])
            context.commit("setLastID", mapSerialize(map))
        }
        ,
        addInLastW(context, value) {
            let map = mapDeserialize(context.state.biIndex.lastW)
            map.set(value[0], value[1])
            context.commit("setLastW", mapSerialize(map))
            // console.log(mapSerialize(map))
        },
        setUserLogin(context, value) {
            context.commit("setUserLogin", value)
        }
    }
}
