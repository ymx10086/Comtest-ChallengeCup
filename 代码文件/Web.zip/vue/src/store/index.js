import Vue from "vue";
import Vuex from "vuex";

import user from './module/user'

Vue.use(Vuex)

export default new Vuex.Store({
    // namespace: true,
    state: {
        iv: "0123456789012345",
    },
    getters: {
        isLogin: (state) => state.user.isLogin,
        user: (state)=>state.user.user,
    },
    mutations: {
        //
    },
    actions: {
        //
    },
    modules: {
        user,
    }
})
