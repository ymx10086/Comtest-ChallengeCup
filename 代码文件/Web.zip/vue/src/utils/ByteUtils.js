/**
 *
 * @param len {number}
 * @returns {ArrayBuffer}
 */
export function getRandomBytes(len) {
    let buf = new ArrayBuffer(len);
    let bufView = new Uint8Array(buf);
    for (let i = 0; i < len; i++) {
        bufView[i] = Math.floor(Math.random()*10);
    }
    // console.log(bufView.buffer === buf)
    return buf;
}

/**
 *
 * @param string1 {ArrayBuffer} utf8
 * @param string2 {ArrayBuffer} utf8
 * @returns {ArrayBuffer}
 */
export function merge(string1, string2) {
    let res = new ArrayBuffer(string1.byteLength + string2.byteLength);
    let uint8Array1 = new Uint8Array(string1);
    let uint8Array2 = new Uint8Array(string2);
    let resInt8Array = new Uint8Array(res);
    for (let i = 0; i < string1.byteLength; i++) {
        resInt8Array[i] = uint8Array1[i];
    }
    for (let i = 0; i < string2.byteLength; i++) {
        resInt8Array[string1.byteLength + i] = uint8Array2[i];
    }
    return res
}

/**
 *
 * @param ab1 {ArrayBuffer}
 * @param ab2 {ArrayBuffer}
 * @return {ArrayBuffer}
 */
export function xor(ab1, ab2) {
    let res = new ArrayBuffer(Math.max(ab1.byteLength, ab2.byteLength))
    let longView, shortView
    if (ab1.byteLength > ab2.byteLength) {
         longView = new Uint8Array(ab1)
         shortView = new Uint8Array(ab2)
    } else {
        longView = new Uint8Array(ab2)
        shortView = new Uint8Array(ab1)
    }
    let resView = new Uint8Array(res)
    let i = 0;
    for (; i < shortView.length; i++) {
        resView[i] = shortView[i] ^ longView[i];
    }
    for (; i < longView.length; i++) {
        resView[i] = longView[i]
    }
    return res
}