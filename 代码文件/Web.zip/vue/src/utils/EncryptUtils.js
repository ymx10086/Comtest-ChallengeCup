import {sha512} from "js-sha512"
import CryptoJS from "crypto-js";
import {sha256} from "js-sha256";
import {arrayBufferToBase64, arrayBufferToString, base64ToArrayBuffer, stringToArrayBuffer} from "@/utils/StringUtils";

/**
 *
 * @param msg {ArrayBuffer}
 * @returns {ArrayBuffer}
 * @constructor
 */
export function SHA512(msg) {
    return sha512.arrayBuffer(msg)
}

/**
 *
 * @param msg {ArrayBuffer}
 * @returns {ArrayBuffer}
 * @constructor
 */
export function SHA256(msg) {
    return sha256.arrayBuffer(msg)
}


/**
 *
 * @param key
 * @param msg
 * @returns {ArrayBuffer} wordArray转换Base64
 * @constructor
 */
export function HmacSHA256(key, msg) {

    // let hash = CryptoJS.HmacSHA256(msg, key); // wordArray
    let hash = CryptoJS.HmacSHA256(arrayBufferToString(msg), arrayBufferToString(key)); // wordArray

    return base64ToArrayBuffer(CryptoJS.enc.Base64.stringify(hash));
}



/**
 * AES对称加密 （CBC模式，需要偏移量）
 * @param msg {ArrayBuffer}
 * @param secretKey {ArrayBuffer}
 * @param iv  {string} vuex中固定
 * @return {ArrayBuffer} ArrayBuffer
 */
export function encryptByAES256(msg, secretKey, iv){
    //明文参数
    let str = CryptoJS.enc.Base64.parse(arrayBufferToBase64(msg)); // 这里为了和Android对接，不能使用utf8
    let key = CryptoJS.enc.Base64.parse(arrayBufferToBase64(secretKey));
    let IV = CryptoJS.enc.Utf8.parse(iv)
    //加密
    let encryptedData = CryptoJS.AES.encrypt(str, key, {
        iv:IV,
        mode: CryptoJS.mode.CBC, //AES加密模式
        padding: CryptoJS.pad.Pkcs7 //填充方式
    });
    // console.log("加密后："+encryptedData);
    return base64ToArrayBuffer(CryptoJS.enc.Base64.stringify(encryptedData.ciphertext)); //返回base64格式密文
}
/**
 * AES对称解密
 * @param msg {ArrayBuffer}
 * @param secretKey {ArrayBuffer}
 * @param iv {string} vuex中固定
 * @returns {ArrayBuffer} utf8
 */
export function decryptByAES256(msg, secretKey, iv){
    //base64格式密文转换
    let base64 = CryptoJS.enc.Base64.parse(arrayBufferToBase64(msg))
    let str = CryptoJS.enc.Base64.stringify(base64)
    let key = CryptoJS.enc.Base64.parse(arrayBufferToBase64(secretKey))
    let IV = CryptoJS.enc.Utf8.parse(iv)
    //解密
    let decryptedData = CryptoJS.AES.decrypt(str, key, {
        iv:IV,
        mode: CryptoJS.mode.CBC, //AES加密模式
        padding: CryptoJS.pad.Pkcs7 //填充方式
    });
    return stringToArrayBuffer(CryptoJS.enc.Utf8.stringify(decryptedData).toString());
}

/**
 *
 * @param fileId {number}
 * @param keyWord {string}
 * @param key1 {ArrayBuffer}
 * @param key2 {ArrayBuffer}
 */
