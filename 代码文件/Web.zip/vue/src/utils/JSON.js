/**
 *
 * @param lastID {Map<string, number>}
 * @return {null}
 */
export function strMapToObj(lastID) {
    let obj = Object.create(null);
    for (let [k, v] of lastID) {
        obj[k] = String(v);
    }
    return obj;
}

/**
 *
 * @return {null}
 * @param obj
 */
// export function numMapToObj(lastW) {
//     let obj = Object.create(null);
//     for (let [k, v] of lastW) {
//         obj[Number(k)] = v; // 这个number强转没有意义
//     }
//     return obj;
// }

export function objToStrMap(obj){
    let strMap = new Map();
    for (let k of Object.keys(obj)) {
        strMap.set(k,obj[k]);
    }
    return strMap;
}

// export function objToNumMap(obj){
//     let strMap = new Map();
//     for (let k of Object.keys(obj)) {
//         strMap.set(Number(k),obj[k]);
//     }
//     return strMap;
// }

/**
 *
 * @param biIndex {Map[]} lastID, lastW
 */
export function biIndexSerialize(biIndex) {
    return JSON.stringify([strMapToObj(biIndex[0]), strMapToObj(biIndex[1])])
}

/**
 *
 * @param lastW {Map}
 * @param lastID {Map}
 */
export function mapsSerialize(lastID, lastW) {
    return biIndexSerialize([lastID, lastW])
}
/**
 *
 * @param strMap
 * @return {Map<any, any>[]}
 */
export function biIndexDeserialize(strMap) {
    let parse = JSON.parse(strMap);
    return [objToStrMap(parse[0]), objToStrMap(parse[1])]
}

export function mapSerialize(map) {
    return JSON.stringify(strMapToObj(map))
}

export function mapDeserialize(map) {
    return objToStrMap(JSON.parse(map))
}