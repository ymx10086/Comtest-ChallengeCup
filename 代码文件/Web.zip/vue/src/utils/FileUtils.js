import {getRandomBytes} from "@/utils/ByteUtils";
import {arrayBufferToBase64, arrayBufferToString} from "@/utils/StringUtils";

/**
 *
 * @param length {number} 需要的utf8字符串长度/字节
 * return {string}
 */
export function getRandomFile(length) {
    // let ab = new ArrayBuffer(length / 8 * 6);
    // let abView = new Uint8Array(ab)
    let res = ""
    // let total = 0;
    while (res.length < length) {
        let randomAB = arrayBufferToBase64(getRandomBytes(Math.floor(Math.random() * 10) + 3));
        if (res.length + randomAB.length < length) {
            res = res + randomAB;
            res = res + " ";
        } else if (res.length + randomAB.length >= length){
            res = res + randomAB.slice(0, length - res.length);
        }
    }
    return res;
}