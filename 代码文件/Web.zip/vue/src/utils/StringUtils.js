import {decode, encode} from "base64-arraybuffer";

/**
 *
 * @param str  {string} utf8字符串
 * @returns {ArrayBuffer}
 */
export function stringToArrayBuffer(str) {
    // 保证和arrayBufferToString的解析方式一致即可
    let buf = new ArrayBuffer(str.length);
    //使用typeArray中的Uint16Array方法设置数据
    let uint8 = new Uint8Array(buf);
    //使用循环设置数据
    for (let i = 0; i < str.length; i++) {
        //使用charCodeAt字符转为二进制编码
        uint8[i] = str.charCodeAt(i);
    }
    return buf
}

/**
 *
 * @param base64Data {string} base6格式的字符串
 * @returns {ArrayBuffer}
 */
export function base64ToArrayBuffer(base64Data) {
    return decode(base64Data)
}

/**
 *
 * @param ab {ArrayBuffer}
 * @returns {string}
 */
export function arrayBufferToString(ab) {
    return  String.fromCharCode.apply(null, new Uint8Array(ab));
}

/**
 *
 * @param ab {ArrayBuffer}
 * @returns {string}
 */
export function arrayBufferToBase64(ab) {
    // return window.btoa(String.fromCharCode(...new Uint8Array(ab)))
    return encode(ab)
}