<template>
    <div class="headerWrapper">
        <el-menu :default-active="activeIndex" class="el-menu-demo" mode="horizontal" router>
            <el-menu-item class="headerItem" index="1" :route="{ name: 'File', query: { fileType: FILE_TYPE.ALL } }">
                加密网盘
            </el-menu-item>
            <el-menu-item class="headerItem userDisplay right-menu-item" v-show="isLogin">
                <el-dropdown>
                    <span class="el-dropdown-link">
                        <el-avatar :size="34" :src="user.imgUrl" fit="cover">
                        <img :src="userImgDefault"/>
                        </el-avatar>
                        <span class="username-header" v-text="user.username"></span>
                    </span>
                    <el-dropdown-menu slot="dropdown">
                        <el-dropdown-item @click.native="changePWDVisible=true">修改密码</el-dropdown-item>
                        <el-dropdown-item @click.native="about()">关于</el-dropdown-item>
                        <el-dropdown-item @click.native="exitButton()">退出</el-dropdown-item>
                    </el-dropdown-menu>
                </el-dropdown>
            </el-menu-item>
            <el-menu-item class="headerItem login right-menu-item" v-show="!isLogin" index="4"
                          :route="{ name: 'Login' }"
            >登录
            </el-menu-item
            >
            <!-- 开发环境 -->
            <el-menu-item
                    class="headerItem register right-menu-item"
                    v-show="!isLogin"
                    index="5"
                    :route="{ name: 'Register' }"
            >注册
            </el-menu-item>
        </el-menu>

        <el-dialog
                title="修改密码"
                :visible.sync="changePWDVisible"
                width="50%"
                :before-close="changePWDClose"
        >
            <div style="height: 100%;width: 75%;clear:both;;overflow:hidden;">
                <el-form :model="changePWDForm" :rules="rules" ref="changePWDForm">
                    <el-form-item label="旧密码" :label-width="formLabelWidth" prop="oldPassWord">
                        <el-input v-model="changePWDForm.oldPassWord" autocomplete="off" show-password></el-input>
                    </el-form-item>
                    <el-form-item label="新密码" :label-width="formLabelWidth" prop="newPassWord">
                        <el-input v-model="changePWDForm.newPassWord" autocomplete="off" show-password></el-input>
                    </el-form-item>
                </el-form>
            </div>
            <span slot="footer" class="dialog-footer">
            <el-button @click="changePWDVisible = false; changePWDForm.newPassWord=''; changePWDForm.oldPassWord=''">取 消</el-button>
            <el-button type="primary" @click="send('changePWDForm');">确 定</el-button>
            </span>
        </el-dialog>
        <el-dialog
                title="关于"
                :visible.sync="aboutVisible"
                width="60%"
        >
                <el-descriptions title="系统信息">
                    <el-descriptions-item label="设计者">陈威</el-descriptions-item>
                    <el-descriptions-item label="指导老师">王蔚</el-descriptions-item>
                    <el-descriptions-item label="必设题目">多用户可搜索密文分享的设计与实现</el-descriptions-item>
                </el-descriptions>
        </el-dialog>
    </div>
</template>

<script>

import {changePassword} from "@/request/user.js";
import {mapGetters} from 'vuex'
import {FILE_TYPE} from "@/global/globalConst";
import {arrayBufferToBase64, base64ToArrayBuffer, stringToArrayBuffer} from "@/utils/StringUtils";
import {encryptByAES256, SHA256, SHA512} from "@/utils/EncryptUtils";
import {merge} from "@/utils/ByteUtils";
import protoCommon from "@/pb_gen/common_pb";

let protoChangePWD = require("@/pb_gen/change_password_pb")
export default {
    name: 'Header',
    data() {
        return {
            logoUrl: require('@/assets/images/common/logo.png'),
            userImgDefault: require('@/assets/images/settings/use.jpg'),
            aboutVisible: false,
            changePWDVisible: false,
            changePWDForm: {
                newPassWord: "",
                oldPassWord: ""
            },
            formLabelWidth: '120px',
            rules: {
                newPassWord: [
                    {required: true, message: '请输入新密码', trigger: 'blur'},
                    {
                        min: 7,
                        max: 20,
                        message: '长度在7到20个字符',
                        trigger: 'blur'
                    }
                ],
                oldPassWord: [
                    {required: true, message: '请输入旧密码', trigger: 'blur'},
                    {
                        min: 7,
                        max: 20,
                        message: '长度在7到20个字符',
                        trigger: 'blur'
                    }
                ]
            }
        }
    },
    computed: {
        FILE_TYPE() {
            return FILE_TYPE
        },
        ...mapGetters(['isLogin', 'user']),
        activeIndex: {
            get() {
                let routerName = this.$route.name
                const ROUTERMAP = {
                    File: '1',
                    Login: '4',
                    Register: '5'
                }
                return ROUTERMAP[routerName]
            },
            set() {
                return '1'
            }
        }
    },
    methods: {
        //  退出登录
        exitButton() {
            this.$store.commit('user/setUserLogout')
            this.$router.push({path: '/login'})
        },
        about() {
            this.aboutVisible = true
        },
        send: function (formName) {
            this.$refs[formName].validate(
                async valid => {
                    if (valid) {
                        //提示语
                        await this.changePWD()
                        this.changePWDVisible = false;
                    }

                }
            )
        },
        async changePWD() {
            let newPwd = this.changePWDForm.newPassWord
            let oldPwd = this.changePWDForm.oldPassWord
            let key1 = base64ToArrayBuffer(this.$cookies.get("key1"))
            let key2 = base64ToArrayBuffer(this.$cookies.get("key2"))
            let usernameAB = stringToArrayBuffer(this.$cookies.get("username"))
            let newPwdAB = stringToArrayBuffer(newPwd)
            let oldPwdAB = stringToArrayBuffer(oldPwd)

            let oldHashID = SHA512(merge(usernameAB, oldPwdAB))
            let newHashID = SHA512(merge(usernameAB, newPwdAB))

            let newPwdSHA256AB = SHA256(newPwdAB)
            let encryptedKey1 = encryptByAES256(key1, newPwdSHA256AB, this.$store.state.iv)
            let encryptedKey2 = encryptByAES256(key2, newPwdSHA256AB, this.$store.state.iv)

            let changePasswordRequest = new protoChangePWD.ChangePasswordRequest()
            changePasswordRequest.setOldhashid(arrayBufferToBase64(oldHashID))
            changePasswordRequest.setNewhashid(arrayBufferToBase64(newHashID))
            changePasswordRequest.setKey1(arrayBufferToBase64(encryptedKey1))
            changePasswordRequest.setKey2(arrayBufferToBase64(encryptedKey2))

            let token = this.$cookies.get("token");
            let baseReq = new protoCommon.BaseReq();
            baseReq.setToken(token);
            changePasswordRequest.setBasereq(baseReq);

            let changePasswordResponse = await changePassword(changePasswordRequest.serializeBinary())
            let changePasswordResponseAB = await changePasswordResponse.data.arrayBuffer()
            const changePasswordResponseData = new protoChangePWD.ChangePasswordResponse.deserializeBinary(new Uint8Array(changePasswordResponseAB))

            if (changePasswordResponseData.getBaseresp().getStatuscode() === protoCommon.StatusCode.SUCCESS) {
                await this.$confirm("密码修改成功", changePasswordResponseData.getBaseresp().getMessage())
            } else {
                await this.$confirm("密码修改失败，旧密码错误", "failed")
            }
            this.changePWDForm.newPassWord = '';
            this.changePWDForm.oldPassWord = ''
        },
        changePWDClose(done) {
            this.changePWDForm.newPassWord = ''
            this.changePWDForm.oldPassWord = ''
            done()
        }
    },
}
</script>

<style lang="stylus" scoped>
@import '~@/assets/styles/varibles.styl'
.headerWrapper
  width 100%
  padding 0 20px
  box-shadow $tabBoxShadow

  >>> .el-menu--horizontal
    .el-menu-item:not(.is-disabled):hover
      border-bottom-color $Primary !important
      background $tabBackColor

  .el-menu-demo
    display flex
    position relative

    .headerLogo
      color $Primary
      font-size 60px
      opacity 1
      cursor default

      a
        display block

      .logo
        height 40px
        vertical-align baseline

    .right-menu-item
      position absolute

    .userDisplay
      right 70px
      width 180px

      .username-header
        margin-left 6px
        min-width 60px
        display inline-block
        text-align center

    .exit
      right 0

    .login
      right 70px

    .register
      right 0px
</style>
