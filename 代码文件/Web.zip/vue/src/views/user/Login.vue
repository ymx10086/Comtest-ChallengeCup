<template>
    <div class="loginWrapper" id="loginBackground">
        <div class="formWrapper">
            <h1 class="loginTitle" v-text="loginTitle"></h1>
            <p class="loginSystem" v-text="SYSTEM_NAME()"></p>
            <el-form
                    :model="ruleForm"
                    :rules="rules"
                    ref="ruleForm"
                    label-width="100px"
                    class="demo-ruleForm"
                    hide-required-asterisk
            >
                <el-form-item prop="username">
                    <el-input
                            prefix-icon="el-icon-user"
                            v-model="ruleForm.username"
                            placeholder="用户名"
                    ></el-input>
                </el-form-item>
                <el-form-item prop="password">
                    <el-input
                            prefix-icon="el-icon-lock"
                            v-model="ruleForm.password"
                            placeholder="密码"
                            show-password
                    ></el-input>
                </el-form-item>
                <el-form-item class="loginButtonWrapper">
                    <el-button class="loginButton" type="primary" @click="loginHandler('ruleForm')">登录
                    </el-button>
                </el-form-item>
            </el-form>
        </div>
    </div>
</template>

<script>
import {login} from '@/request/user.js'
import {arrayBufferToBase64, arrayBufferToString, base64ToArrayBuffer, stringToArrayBuffer} from "@/utils/StringUtils";
import {decryptByAES256, SHA256, SHA512} from "@/utils/EncryptUtils";
import {merge} from "@/utils/ByteUtils";
import {SYSTEM_NAME} from "@/global/globalConst";


// const egCustom = new ElGamal(prime, generator, publicKey, privateKey);
const protoUserLogin = require('@/pb_gen/user_login_pb')
const protoCommon = require('@/pb_gen/common_pb')
export default {
    name: 'Login',
    data() {
        return {
            loginTitle: '登录',
            ruleForm: {
                username: '',
                password: '',
                rememberMe: ''
            },
            rules: {
                username: [
                    {required: true, message: '请输入用户名', trigger: 'blur'},
                    {
                        min: 4,
                        max: 16,
                        message: '长度在4到16个字符',
                        trigger: 'blur'
                    }
                ],
                password: [
                    {required: true, message: '请输入密码', trigger: 'blur'},
                    {
                        min: 7,
                        max: 20,
                        message: '长度在7到20个字符',
                        trigger: 'blur'
                    }
                ],
            },
            isPassing: false,
            submitDisabled: true,
            qqIcon: require('@/assets/images/login/qqIcon.png')
        }
    },
    computed: {
        url() {
            let _url = this.$route.query.Rurl //获取路由前置守卫中next函数的参数，即登录后要去的页面
            if (_url) {
                //若登录之前有页面，则登录后仍然进入该页面
                return _url
            } else {
                //若登录之前无页面，则登录后进入首页
                return '/'
            }
        }
    },
    watch: {},
    methods: {
        SYSTEM_NAME() {
            return SYSTEM_NAME
        },
        //  记住我
        rememberMe(isPassing) {
            if (isPassing) {
                this.ruleForm.rememberMe = 'On'
            } else {
                this.ruleForm.rememberMe = ''
            }
        },
        //  登录按钮
        loginHandler: async function (formName) {

            this.$refs[formName].validate(async valid => {
                if (valid) {
                    let userLoginRequest = new protoUserLogin.UserLoginRequest();
                    let userName = this.ruleForm.username
                    let passWord = this.ruleForm.password
                    let hashId = arrayBufferToBase64(SHA512(merge(stringToArrayBuffer(userName), stringToArrayBuffer(passWord))));
                    // console.log(hashId)
                    userLoginRequest.setUsername(userName);
                    userLoginRequest.setHashid(hashId);
                    // const handleResp = this.handleResp;
                    let response = await login(userLoginRequest.serializeBinary())
                    let data = await response.data.arrayBuffer()
                    // this.handleResp(data);
                    const resp = new protoUserLogin.UserLoginResponse.deserializeBinary(new Uint8Array(data))
                    // console.log(resp)
                    //校验请求是否成功
                    if (resp.getBaseresp().getStatuscode() === protoCommon.StatusCode.USERNOTFOUND) {
                        await this.$confirm("用户不存在", resp.getBaseresp().getMessage())
                    } else if (resp.getBaseresp().getStatuscode() === protoCommon.StatusCode.WRONGPASSWD) {
                        await this.$confirm("密码错误", resp.getBaseresp().getMessage())
                    } else if ((resp.getBaseresp().getStatuscode() === protoCommon.StatusCode.SUCCESS)) {
                        console.log(resp.getBaseresp().getMessage())
                        this.$notify({
                            title: "登录成功",
                            message: resp.getBaseresp().getMessage(), // 这地方很诡异,现在为什么会对啊
                            // message: "resp.getBaseresp().getMessage()",
                            type: "success"
                        })

                        this.$cookies.set("token", resp.getToken(), "1y");
                        let info = resp.getUserinfo();
                        let pwd2SHA256 = SHA256(stringToArrayBuffer(this.ruleForm.password))
                        this.$cookies.set("username", info.getUsername(), "1y");
                        this.$cookies.set("rootID", info.getRootid(), "1y");
                        console.log("rootId", String(info.getRootid()));
                        // this.$cookies.set("masterKey", sha256(this.ruleForm.username).slice(0, 32), "1y");
                        let key1 = decryptByAES256(base64ToArrayBuffer(info.getKey1()),
                            pwd2SHA256, this.$store.state.iv);
                        let key2 = decryptByAES256(base64ToArrayBuffer(info.getKey2()),
                            pwd2SHA256, this.$store.state.iv);
                        this.$cookies.set("key1", arrayBufferToBase64(key1), "1y");// 注意这两个东西在cookie中的存储方式
                        this.$cookies.set("key2", arrayBufferToBase64(key2), "1y");
                        // console.log("key1", arrayBufferToBase64(key1))
                        // console.log("key2", arrayBufferToBase64(key2))
                        this.$cookies.set("email", info.getEmail(), "1y");
                        this.$cookies.set("biIndex", arrayBufferToString(base64ToArrayBuffer(info.getBiindex())), "1y") // 注意其存储方式，每次从cookies中那出来使用都需要更新
                        await this.$store.dispatch("user/setBiIndex", arrayBufferToString(base64ToArrayBuffer(info.getBiindex())))
                        // 这里还需要对于BiIndex进行一下操作，并保存在cookie中
                        /*this.$router.replace({name:'Home'});*/
                        await this.$store.dispatch("user/setUserLogin", {
                            username: this.ruleForm.username,
                            imgUrl: '',
                            email: info.getEmail()
                        })
                        await this.$router.push({path: '/file'});
                    } else {
                        await this.$confirm("服务器错误", resp.getBaseresp().getMessage())
                    }
                    if (this.ruleForm.rememberMe !== 'On') {
                        this.ruleForm.password = ""
                        this.ruleForm.username = ""
                    }
                }
            })
        },
    }
}

</script>
<style lang="stylus" scoped>
.loginWrapper
  height 550px !important
  min-height 550px !important
  padding-top 50px

  .formWrapper
    width 375px
    margin 0 auto
    text-align center

    .loginTitle
      margin-bottom 10px
      font-weight 300
      font-size 30px
      color #000

    .loginSystem
      font-weight 300
      color #999

    .demo-ruleForm
      width 100%
      margin-top 20px

      >>> .el-form-item__content
        margin-left 0 !important

      & >>> .el-input__inner
        font-size 16px

      .loginButtonWrapper
        .loginButton
          width 100%

        & >>> .el-button
          padding 10px 90px
          font-size 16px

    .tip
      width 70%
      margin-left 86px
</style>
