<template>
    <div class="registerWrapper" id="registerBackground">
        <div class="formWrapper">
            <h1 class="registerTitle" v-text="registerTitle"></h1>
            <p class="registerSystem" v-text="SYSTEM_NAME"></p>
            <el-form
                    :model="ruleForm"
                    :rules="rules"
                    ref="ruleForm"
                    label-width="100px"
                    class="demo-ruleForm"
                    hide-required-asterisk
            >
                <el-form-item prop="username">
                    <el-input
                            prefix-icon="el-icon-user"
                            v-model="ruleForm.username"
                            placeholder="用户名"
                    ></el-input>
                </el-form-item>
                <el-form-item prop="email">
                    <el-input
                            prefix-icon="el-icon-message"
                            v-model="ruleForm.email"
                            placeholder="邮箱"
                    ></el-input>
                </el-form-item>
                <el-form-item prop="password">
                    <el-input
                            prefix-icon="el-icon-lock"
                            v-model="ruleForm.password"
                            placeholder="密码"
                            show-password
                    ></el-input>
                </el-form-item>
                <el-form-item style="user-select: none;">
                    <drag-verify
                            ref="dragVerifyRef"
                            text="请按住滑块拖动解锁"
                            successText="验证通过"
                            handlerIcon="el-icon-d-arrow-right"
                            successIcon="el-icon-circle-check"
                            :width="375"
                            handlerBg="#F5F7FA"
                            :isPassing.sync="isPassing"
                            @update:isPassing="updateIsPassing"
                    ></drag-verify>
                </el-form-item>

                <el-form-item class="registerButtonWrapper">
                    <el-button
                            class="registerButton"
                            type="primary"
                            :disabled="submitDisabled"
                            @click="registerHandler('ruleForm')"
                    >注册
                    </el-button>
                </el-form-item>
            </el-form>
        </div>
    </div>
</template>

<script>
import CanvasNest from 'canvas-nest.js'
import {addUser} from '@/request/user.js'
import DragVerify from '@/components/DragVerify.vue'
import {encryptByAES256, SHA256, SHA512} from "@/utils/EncryptUtils";
import {getRandomBytes, merge} from "@/utils/ByteUtils";
import {arrayBufferToBase64, stringToArrayBuffer} from "@/utils/StringUtils";
import {mapsSerialize} from "@/utils/JSON";

var protoUserRegister = require('@/pb_gen/user_register_pb')
var protoCommon = require('@/pb_gen/common_pb')
// 配置
const config = {
    color: '230, 162, 60', // 线条颜色
    pointColor: '230, 162, 60', // 节点颜色
    opacity: 0.5, // 线条透明度
    count: 99, // 线条数量
    zIndex: -1 // 画面层级
}

export default {
    name: 'Register',
    components:{
        DragVerify
    },
    data() {
        return {
            registerTitle: '注册',
            ruleForm: {
                email: '',
                username: '',
                password: ''
                /*token: ''*/
            },
            rules: {
                username: [
                    {required: true, message: '请输入用户名', trigger: 'blur'},
                    {
                        min: 4,
                        max: 16,
                        message: '长度在4到16个字符',
                        trigger: 'blur'
                    }
                ],
                password: [
                    {required: true, message: '请输入密码', trigger: 'blur'},
                    {
                        min: 7,
                        max: 20,
                        message: '长度在7到20个字符',
                        trigger: 'blur'
                    }
                ],
                email: [
                    {required: true, message: '请输入邮箱地址', trigger: 'blur'},
                    {type: 'email', message: '请输入正确的邮箱地址', trigger: ['blur', 'change']}
                ]

            },
            isPassing: false,
            submitDisabled: true,

            key: {
                privateKey: '',
                publicKey: ''
            }
        }
    },
    computed: {
        url() {
            let _url = this.$route.query.Rurl //获取路由前置守卫中next函数的参数，即登录后要去的页面
            if (_url) {
                //若登录之前有页面，则登录后仍然进入该页面
                return _url
            } else {
                //若登录之前无页面，则登录后进入首页
                return '/'
            }
        }
    },
    watch: {
         // 已验证通过时，若重新输入邮箱、用户名或密码，滑动解锁恢复原样
        'ruleForm.email'() {
            this.isPassing = false
            this.submitDisabled = true
            this.$refs.dragVerifyRef.reset()
        },
        'ruleForm.userName'() {
            this.isPassing = false
            this.submitDisabled = true
            this.$refs.dragVerifyRef.reset()
        },
        'ruleForm.password'() {
            this.isPassing = false
            this.submitDisabled = true
            this.$refs.dragVerifyRef.reset()
        }
    },
    created() {
        this.$nextTick(() => {
            let element = document.getElementById('registerBackground')
            new CanvasNest(element, config)
        })
    },
    methods: {
        //  滑动解锁完成
        updateIsPassing(isPassing) {
            if (isPassing) {
                //  校验邮箱
                this.$refs.ruleForm.validateField('email', emailError => {
                    if (emailError) {
                        this.submitDisabled = true
                    } else {
                        this.submitDisabled = false
                    }
                })
            } else {
                this.submitDisabled = true
            }
        },

        registerHandler(formName) {
            this.$refs[formName].validate(async valid => {
                if (valid) {
                    //  各项校验通过
                    let userRegisterRequest = new protoUserRegister.UserRegisterRequest();
                    let userName = this.ruleForm.username;
                    let email = this.ruleForm.email;
                    let password = this.ruleForm.password;

                    // 生成登录凭证hashId
                    let hashId = arrayBufferToBase64(
                        SHA512(merge(stringToArrayBuffer(userName),
                        stringToArrayBuffer(password))));
                    // 需要对其进行序列化，但是java中的那种形式不能使用
                    let lastW = new Map()
                    let lastID = new Map()
                    let biIndexJson = mapsSerialize(lastID, lastW);
                    // 用户的密钥
                    let key1 = getRandomBytes(32);
                    let key2 = getRandomBytes(32);

                    let pwd2SHA256 = SHA256(password);
                    let encryptedKey1 = arrayBufferToBase64(encryptByAES256(key1, pwd2SHA256, this.$store.state.iv))
                    let encryptedKey2 = arrayBufferToBase64(encryptByAES256(key2, pwd2SHA256, this.$store.state.iv))
                    userRegisterRequest.setHashid(hashId);
                    userRegisterRequest.setEmail(email)
                    userRegisterRequest.setUsername(userName)
                    userRegisterRequest.setKey1(encryptedKey1)
                    userRegisterRequest.setKey2(encryptedKey2)
                    userRegisterRequest.setBiindex(arrayBufferToBase64(stringToArrayBuffer(biIndexJson)));

                    let response = await addUser(userRegisterRequest.serializeBinary())
                    let data = await response.data.arrayBuffer()
                    this.handleResp(data)

                }
            })
        },
        handleResp: function (data) {
            let resp = new protoUserRegister.UserRegisterResponse.deserializeBinary(new Uint8Array(data))
            //todo校验用户重复创建
            if (resp.getBaseresp().getStatuscode() !== protoCommon.StatusCode.SUCCESS) {
                if (resp.getBaseresp().getStatuscode() === protoCommon.StatusCode.USEREXIST) {
                    this.$confirm("用户已存在，是否直接登录?").then(() => {
                        this.$router.replace({path: 'login'})
                    })
                    return;
                }
                this.$alert({
                    title: "Internal Server Error",
                    type: "error"
                })
                return;
            }
            this.$confirm("注册成功，是否跳转登录?", "Success", "success").then(() => {
                this.$router.replace({path: 'login'})
            })
        },


    }
}
</script>
<style lang="stylus" scoped>
.registerWrapper
  height: 500px !important
  min-height: 500px !important
  width: 100% !important
  padding-top: 50px

  .formWrapper
    width: 375px
    margin: 0 auto
    text-align: center

    .registerTitle
      margin-bottom: 10px
      font-weight: 300
      font-size: 30px
      color: #000

    .registerSystem
      font-weight: 300
      color: #999

    .demo-ruleForm
      width: 100%
      margin-top: 20px

      >>> .el-form-item__content
        margin-left: 0 !important

      & >>> .el-input__inner
        font-size: 16px

      .registerButtonWrapper
        .registerButton
          width: 100%

        & >>> .el-button
          padding: 10px 90px
          font-size: 16px

    .tip
      width: 70%
      margin-left: 86px
</style>
