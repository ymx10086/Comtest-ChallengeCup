<template>
    <div class="file-wrapper">
        <div class="tools">
            <div class="refresh-button" style="align-content: center; float: left">
                <el-button size="small" icon="el-icon-refresh" id="flush" @click="getDirHandler">
                </el-button>
            </div>
            <div class="upload-button" style="align-content: center;float:left;margin-left: 10px">
                <el-upload
                        ref="upload"
                        class="upload-demo"
                        action="#"
                        accept="."
                        :on-change="uploadFile"
                        :auto-upload="false"
                        :show-file-list="false">
                    <el-button size="small" type="" icon="el-icon-upload">上传</el-button>
                </el-upload>
            </div>
            <div class="recv-share-button" style="align-content: center; float: left; margin-left: 10px">
                <el-button size="small" icon="el-icon-plus" id="recv-share"
                           @click="createDirDialogVisible = true">创建文件夹
                </el-button>
            </div>
            <div class="recv-share-button" style="align-content: center; float: left; margin-left: 10px">
                <el-button size="small" icon="el-icon-message" id="recv-share"
                           @click="getShareTokensHandler();recvdialogVisible = true">分享消息
                </el-button>
            </div>

            <!--            <div class="recv-share-button" style="align-content: center; float: left; margin-left: 10px">-->
            <!--                <el-button size="small" icon="el-icon-message" id="recv-share"-->
            <!--                           @click="uploadTest();"> 测试上传-->
            <!--                </el-button>-->
            <!--            </div>-->
            <!--            <div class="recv-share-button" style="align-content: center; float: left; margin-left: 10px">-->
            <!--                <el-button size="small" icon="el-icon-message" id="recv-share"-->
            <!--                           @click="searchFileTest();"> 测试搜索-->
            <!--                </el-button>-->
            <!--            </div>-->
            <div class="search-button" style="align-content: center;float: left;margin-left: 10px">
                <el-select
                        v-model="keyword"
                        filterable
                        remote
                        reserve-keyword
                        placeholder="请输入关键词"
                        :remote-method="searchFileHandler"
                        :loading="loading"
                        loading-text="搜索中"
                        @change="showDetail"
                        @visible-change="options=[]"
                >
                    <el-option
                            v-for="item in options"
                            :key="item.nodeid"
                            :label="item.nodename"
                            :value="item.nodeid"
                    >
                    </el-option>
                </el-select>
            </div>

        </div>
        <div class="showFileList">
            <el-table
                    :data="this.fileList"
                    style="width: 100%"
            >
                <el-table-column type="selection" width="55"></el-table-column>
                <el-table-column prop="nodetype" label="类型" width="100%">
                    <template slot-scope="scope">
          <span v-if="scope.row.nodetype !== 1">
            <el-image :src="require('@/assets/images/file/dir.png')" style="width: 50px;"></el-image>
          </span>
                        <span v-else>
            <el-image :src="require('@/assets/images/file/file_txt.png')" style="width: 40px;"></el-image>
          </span>
                    </template>

                </el-table-column>

                <el-table-column prop="nodename" label="名称" width="200">
                </el-table-column>
                <el-table-column prop="createtime" label="创建时间" :formatter="dataFormat" width="200">
                </el-table-column>
                <el-table-column prop="updatetime" label="更新时间" :formatter="dataFormat" width="200">
                </el-table-column>
                <el-table-column prop="nodeid" label="查看" width="90">
                    <template slot-scope="scope">
                        <el-button size="mini" icon="el-icon-view" id="viewFile" v-if="scope.row.nodetype === 0"
                                   @click="returnBack()">
                        </el-button>
                        <el-button size="mini" icon="el-icon-view" id="viewFile" v-if="scope.row.nodetype === 1"
                                   @click="getContent(scope.row.nodeid);dialogVisible = true">
                        </el-button>
                        <!--                        <el-button size="mini" icon="el-icon-view" id="viewFile" v-if="scope.row.nodetype === 2"-->
                        <el-button size="mini" icon="el-icon-view" id="viewFile" v-if="scope.row.nodetype === 2"
                                   @click="enter(scope.row.nodeid)">
                        </el-button>

                    </template>
                </el-table-column>
                <el-table-column prop="nodeid" label="分享" width="80">
                    <template slot-scope="scope">
                        <el-button size="mini" icon="el-icon-share" id="shareFile" v-if="scope.row.nodetype === 1"
                                   @click="shareSingleFile(scope.row.nodeid, scope.row.nodename);">
                        </el-button>
                        <el-button size="mini" icon="el-icon-share" id="shareFile" v-if="scope.row.nodetype === 2"
                                   @click="sharePatchFile(scope.row.nodeid, scope.row.nodename);">
                        </el-button>
                    </template>
                </el-table-column>
                <el-table-column prop="nodeid" label="删除" width="80">
                    <template slot-scope="scope">
                        <!--                    加入删除函数-->
                        <el-button size="mini" icon="el-icon-delete" id="deleteFile" v-if="scope.row.nodetype !== 0"
                                   @click="deleteFileOrDirHandler(scope.row.nodeid, scope.row.nodetype)">
                        </el-button>
                    </template>
                </el-table-column>
            </el-table>
            <el-dialog
                    :title="showFileName + '文件内容'"
                    :visible.sync="dialogVisible"
                    width="50%">
                <div style="height: 100%;width: 100%;clear:both;overflow:hidden;">
                    {{ showContent }}
                </div>
                <el-button type="primary" @click="dialogVisible = false">确 定</el-button>

            </el-dialog>
            <!--            仿照分享操作，写一个文件夹创建的功能-->
            <el-dialog
                    title="文件分享"
                    :visible.sync="sharedialogVisible"
                    :before-close="fileShareClose"
                    width="50%"
            >
                <div style="height: 100%;width: 100%;clear:both;;overflow:hidden;">
                    <el-form :model="shareForm">
                        <el-form-item label="被分享者用户名" :label-width="formLabelWidth">
                            <el-input v-model="shareForm.receiveName" autocomplete="off"></el-input>
                        </el-form-item>
                        <el-form-item label="操作" :label-width="formLabelWidth">
                            <el-radio v-model="shareForm.isShare" label="0">转存</el-radio>
                            <el-radio v-model="shareForm.isShare" label="1">分享</el-radio>
                        </el-form-item>
                    </el-form>
                </div>
                <span slot="footer" class="dialog-footer">
          <el-button
                  @click="sharedialogVisible = false;this.shareForm.shareFileName = '';this.shareForm.receiveName ='';this.shareForm.shareFileKey = '';this.shareForm.shareFileId ='';shareForm.isShare = '1'">取 消</el-button>
          <el-button type="primary"
                     @click="uploadShareTokenHandler(shareForm);sharedialogVisible = false;">确 定</el-button>
        </span>
            </el-dialog>
            <el-dialog
                    title="创建文件夹"
                    :visible.sync="createDirDialogVisible"
                    :before-close="createDirClose"
                    width="50%"
            >
                <div style="height: 100%;width: 100%;clear:both;;overflow:hidden;">
                    <el-form :model="createDirForm">
                        <el-form-item label="文件夹名称" :label-width="formLabelWidth">
                            <el-input v-model="createDirForm.dirName" autocomplete="off"></el-input>
                        </el-form-item>
                    </el-form>
                </div>
                <span slot="footer" class="dialog-footer">
          <el-button @click="createDirDialogVisible = false; createDirForm.dirName=''">取 消</el-button>
          <el-button type="primary"
                     @click="createDirHandler(createDirForm);createDirDialogVisible = false;">确 定</el-button>
        </span>
            </el-dialog>

            <el-dialog
                    title="分享消息"
                    :visible.sync="recvdialogVisible"
                    width="50%"
            >
                <el-table :data="this.shareTokenList">
                    <!--                    <el-table-column property="shareid" label="消息" width="150"></el-table-column>-->
                    <el-table-column property="filename" label="文件名" width="150"></el-table-column>
                    <el-table-column property="sharetoken.ownerid" label="分享者"></el-table-column>
                    <el-table-column property="isshare" label="类型">
                    </el-table-column>
                    <el-table-column property="createtime" label="分享时间" :formatter="dataFormat"></el-table-column>
                    <el-table-column property="sharetoken.userid" width="100">
                        <template slot-scope="scope">
                            <el-button size="mini" type="primary" id="agree"
                                       @click="receiveShareTokenHandler(scope.row.sharetoken.l,scope.row.sharetoken.jid, scope.row.sharetoken.kid, scope.row.secretkey, scope.row.filename, scope.row.sharetoken.fileid, scope.row.sharetokenid, scope.row.isshare);recvdialogVisible=false">
                                接收
                            </el-button>
                        </template>
                    </el-table-column>
                </el-table>
            </el-dialog>
        </div>


    </div>


</template>

<script>

import moment from "moment";
import {
    createDir,
    deleteFile,
    deleteShareToken,
    getDir,
    getNodeId,
    getNodeRemote,
    getShareTokens,
    searchFile,
    sendSearchToken,
    shareFirstWithServer,
    shareSecondWithServer,
    uploadFile,
    uploadShareToken
} from "@/request/file";
import {getRandomBytes, merge, xor} from "@/utils/ByteUtils";
import {decryptByAES256, encryptByAES256, HmacSHA256, SHA512} from "@/utils/EncryptUtils";
import {arrayBufferToBase64, arrayBufferToString, base64ToArrayBuffer, stringToArrayBuffer} from "@/utils/StringUtils";
// import {getRandomFile} from "@/utils/FileUtils";

let protoCommon = require("@/pb_gen/common_pb");
let protoGetDir = require("@/pb_gen/get_dir_pb");
let protoSearchFile = require("@/pb_gen/search_file_pb");
let protoUploadFile = require("@/pb_gen/upload_file_pb");
let protoGetNodeId = require("@/pb_gen/get_node_id_pb");
let protoCreateDir = require("@/pb_gen/create_dir_pb");
let protoGetNode = require("@/pb_gen/get_node_pb");
let protoSendSearchToken = require("@/pb_gen/send_search_token_pb")
let protoDeleteFile = require("@/pb_gen/delete_file_pb")
let protoUploadShareToken = require("@/pb_gen/upload_share_token_pb")
let protoGetShareTokens = require("@/pb_gen/get_share_tokens_pb")
let protoShareFirst = require("@/pb_gen/share_first_pb")
let protoShareSecond = require("@/pb_gen/share_second_pb")
let protoDeleteShareToken = require("@/pb_gen/delete_share_token_pb")

// 需要添加一个创建文件夹的功能
export default {

    data() {

        return {

            fileList: [],
            upload_content: "",
            upload_filename: "",
            indexlistList: [],
            keyword: "",
            loading: false,
            options: [],
            searchResp: [],
            dialogVisible: false,

            sharedialogVisible: false,
            shareForm: {
                receiveName: '',
                shareFileId: 0,
                shareFileKey: '',
                shareFileName: "",
                isShare: '1'
            },
            formLabelWidth: '120px',
            recvdialogVisible: false,
            sharedList: [],
            parentId: 0,
            // nodeId: "", // 暂存从服务器获取的nodeId
            createDirDialogVisible: false,
            createDirForm: {
                dirName: ""
            },
            showContent: "",
            showFileName: "",
            shareTokenList: [],
            browserList: [],
            totalTimeTest1: 0,
            totalTimeTest2: 0
        }
    },

    activated() {
        this.fileList = [];
        this.parentId = this.$cookies.get("rootID")
        this.getDirHandler();
    },


    methods: {
        dataFormat: function (row, column) {
            var date = row[column.property] * 1000;  //获取传过来的时间
            if (date === undefined) {          //判断时间是否为空
                return "";                      //如果为空就返回一个空的字符串
            }
            return moment(date).format("YYYY-MM-DD HH:mm:ss");
            //如果值不为空，就把传过来的那个时间，按格式修改，然后返回
        },

        async getDirHandler() {// 根据parentId获取目录节点信息, 除了根节点外，需要能够将所有的信息全部取出
            this.fileList = []
            const nodes = await this.getDirInfo(this.parentId);
            nodes.map(
                (node) => {
                    this.fileList.push(node.toObject())
                    // console.log("fileList", node.toObject())
                }
            )
            this.FileAndDirSort()
            // 在添加一个返回上层结点
            if (this.parentId !== this.$cookies.get("rootID")) {
                let backNode = new protoCommon.Node()
                backNode.setNodename("...")
                backNode.setNodetype(protoCommon.NodeType.UNKNOWN)
                backNode.setCreatetime(new Date().getTime() / 1000)
                backNode.setUpdatetime(new Date().getTime() / 1000)
                this.fileList.unshift(backNode.toObject())
            }
        },
        getDirInfo: async function (nodeId) {
            let getDirRequest = new protoGetDir.GetDirRequest();
            console.log("getInfo NodeID", nodeId)
            // getDirRequest.setNodeid(this.parentId);
            getDirRequest.setNodeid(nodeId);
            // console.log("getLastId", this.$store.getters["user/getLastId"])

            let token = this.$cookies.get("token");
            let baseReq = new protoCommon.BaseReq();
            baseReq.setToken(token);
            getDirRequest.setBasereq(baseReq);

            let getDirResponse = await getDir(getDirRequest.serializeBinary())
            let getDirResponseAB = await getDirResponse.data.arrayBuffer()

            // this.getDirHandleResp(data)
            const getDirResponseData = new protoGetDir.GetDirResponse.deserializeBinary(new Uint8Array(getDirResponseAB))
            const node = getDirResponseData.getNodeidlistList();

            // 拿到所有的节点后，需要再发起一次请求，将详细的信息获取到。
            let searchFileRequest = new protoSearchFile.SearchFileRequest();
            searchFileRequest.setNodeidList(node);
            baseReq.setToken(token);
            searchFileRequest.setBasereq(baseReq);

            let searchFileResponse = await searchFile(searchFileRequest.serializeBinary())
            let searchFileResponseAB = await searchFileResponse.data.arrayBuffer()

            const searchFileResponseData = new protoSearchFile.SearchFileResponse.deserializeBinary(new Uint8Array(searchFileResponseAB))
            // const nodes = searchFileResponseData.getNodelistList();
            return searchFileResponseData.getNodelistList();
        }
        ,
        uploadFile(file) {
            let reader = new FileReader();
            reader.readAsText(file.raw);
            reader.onload = (e) => {
                this.uploadFileHandler(e, file)
            };
        },
        uploadFileHandler: async function (e, file) {
            console.log("test")
            let uploadFileRequest = new protoUploadFile.UploadFileRequest()


            this.upload_content = e.target.result; // 直接获取文本文件的
            this.upload_filename = file.name;
            let fileSecret = getRandomBytes(32);

            let cipherText = arrayBufferToBase64(encryptByAES256(stringToArrayBuffer(e.target.result), fileSecret, this.$store.state.iv));

            let encryptedFileSecret = arrayBufferToBase64(encryptByAES256(fileSecret, base64ToArrayBuffer(this.$cookies.get("key2")), this.$store.state.iv))

            if (cipherText.length === 0) {
                cipherText = ""
            }
            let nodeId = await this.getNodeId()
            // console.log("getNodeId", String(nodeId))
            let key1 = base64ToArrayBuffer(this.$cookies.get("key1"))
            let key2 = base64ToArrayBuffer(this.$cookies.get("key2"))

            let indexList = this.indexList(e.target.result, nodeId, key1, key2)

            let biIndex = this.$store.getters["user/getBiIndex"]

            let token = this.$cookies.get("token");
            let baseReq = new protoCommon.BaseReq();
            baseReq.setToken(token);
            uploadFileRequest.setBasereq(baseReq);


            uploadFileRequest.setFilename(file.name)
            uploadFileRequest.setParentid(this.parentId)
            uploadFileRequest.setIndexlistList(indexList)
            uploadFileRequest.setContent(new Uint8Array(stringToArrayBuffer(cipherText)))
            uploadFileRequest.setBiindex(arrayBufferToBase64(stringToArrayBuffer(biIndex)))
            uploadFileRequest.setNodeid(Number(nodeId));
            uploadFileRequest.setFilesecret(encryptedFileSecret);

            // console.log(up)
            let uploadFileResponse = await uploadFile(uploadFileRequest.serializeBinary())
            let uploadFileResponseAB = await uploadFileResponse.data.arrayBuffer()
            const uploadFileResponseData = new protoUploadFile.UploadFileReponse.deserializeBinary(new Uint8Array(uploadFileResponseAB))
            if (uploadFileResponseData.getBaseresp().getStatuscode() === protoCommon.StatusCode.SUCCESS) {
                await this.getDirHandler();
                await this.$confirm("上传成功", uploadFileResponseData.getBaseresp().getMessage())
            }
        },

        getNodeId: async function () {
            let getNodeIdRequest = new protoGetNodeId.GetNodeIdRequest();

            let token = this.$cookies.get("token");
            let baseReq = new protoCommon.BaseReq();
            baseReq.setToken(token);
            getNodeIdRequest.setBasereq(baseReq);

            // const handleResp = this.getNodeIdHandleResp;

            let getNodeIdResponse = await getNodeId(getNodeIdRequest.serializeBinary())
            let getNodeIdResponseAB = await getNodeIdResponse.data.arrayBuffer()
            // return getNodeIdResponseAB;
            const getNodeIdResponseData = new protoGetNodeId.GetNodeIdResponse.deserializeBinary(new Uint8Array(getNodeIdResponseAB))
            // this.nodeId = "" + getNodeIdResponseData.getNodeid()
            return getNodeIdResponseData.getNodeid()
        },
        indexList: function (content, fileId, key1, key2) {
            let words = [];
            let word = "";
            for (let i = 0; i < content.length; i++) {
                let char = content[i];
                if ((char >= 'a' && char <= 'z')
                    || (char >= 'A' && char <= 'Z')
                    || (char >= '0' && char <= '9')) {
                    word += char
                } else {
                    if (word.length > 0) {
                        words.push(word)
                        word = ""
                    }
                }
            }
            if (word.length > 0) {
                words.push(word)
            }
            let indexList = [];
            for (let i = 0; i < words.length; i++) {
                indexList.push(this.searchIndexGen(fileId,
                    words[i], key1, key2))
            }
            return indexList
        },
        searchIndexGen: function (fileId, keyWord, key1, key2) { // number string arraybuffer arraybuffer
            let lastW = this.$store.getters['user/getLastW']
            let lastID = this.$store.getters["user/getLastId"]

            let oldWord = lastW.get(String(fileId))
            let oldIDString = lastID.get(keyWord)

            let idAB = stringToArrayBuffer(String(fileId))
            let wAB = stringToArrayBuffer(keyWord)

            let id_w = merge(idAB, wAB)
            let w_id = merge(wAB, idAB)

            let L = HmacSHA256(key1, w_id)

            let Rw = getRandomBytes(32)
            let Rid = getRandomBytes(32)

            let kw = HmacSHA256(key2, wAB)
            let kid = HmacSHA256(key2, idAB)

            let cw = encryptByAES256(idAB, kw, this.$store.state.iv)
            let cid = encryptByAES256(wAB, kid, this.$store.state.iv)
            let Iw
            if (oldIDString === undefined) {
                // 如果为新关键词
                let Jw = HmacSHA256(key2, w_id)
                Iw = SHA512(merge(Jw, Rw))
            } else {
                let oldIdAB = stringToArrayBuffer(oldIDString)
                let oldL = HmacSHA256(key1, merge(wAB, oldIdAB))
                let oldJw = HmacSHA256(key2, merge(wAB, oldIdAB))
                let Jw = HmacSHA256(key2, w_id)
                Iw = xor(SHA512(merge(Jw, Rw)), merge(oldL, oldJw))
            }
            let Iid
            if (oldWord === undefined) {
                let Jid = HmacSHA256(key2, id_w)
                Iid = SHA512(merge(Jid, Rid))
            } else {
                let oldWAB = stringToArrayBuffer(oldWord)
                let oldL = HmacSHA256(key1, merge(oldWAB, idAB))
                let oldJid = HmacSHA256(key2, merge(idAB, oldWAB))
                let Jid = HmacSHA256(key2, id_w)
                Iid = xor(SHA512(merge(Jid, Rid)), merge(oldL, oldJid))
            }
            this.$store.dispatch("user/addInLastW", [fileId, keyWord])
            this.$store.dispatch("user/addInLastID", [keyWord, fileId])
            let indexToken = new protoCommon.indexToken()
            indexToken.setL(arrayBufferToBase64(L))
            indexToken.setIw(arrayBufferToBase64(Iw))
            indexToken.setRw(arrayBufferToBase64(Rw))
            indexToken.setCw(arrayBufferToBase64(cw))
            indexToken.setIid(arrayBufferToBase64(Iid))
            indexToken.setRid(arrayBufferToBase64(Rid))
            indexToken.setCid(arrayBufferToBase64(cid))
            console.log(keyWord, indexToken)
            return indexToken;
        },
        enter: async function (nodeId) { // 进入下一层
            this.browserList.push(this.parentId)
            this.parentId = nodeId;
            await this.getDirHandler();

        },
        returnBack: async function () {
            this.parentId = this.browserList.pop();
            await this.getDirHandler();
        },
        createDirClose(done) {
            this.createDirForm.dirName = ''
            done()
        },
        createDirHandler: async function (form) { // 创建文件夹

            let fileName = form.dirName;
            let createDirRequest = new protoCreateDir.CreateDirRequest();
            createDirRequest.setDirname(fileName);
            createDirRequest.setParentid(this.parentId);

            let token = this.$cookies.get("token");
            let baseReq = new protoCommon.BaseReq();
            baseReq.setToken(token);
            createDirRequest.setBasereq(baseReq);

            let createDirResponse = await createDir(createDirRequest.serializeBinary())
            let createDirResponseAB = await createDirResponse.data.arrayBuffer()
            const createDirResponseData = new protoCreateDir.CreateDirResponse.deserializeBinary(new Uint8Array(createDirResponseAB))
            if (createDirResponseData.getBaseresp().getStatuscode() === protoCommon.StatusCode.SUCCESS) {
                await this.getDirHandler();
                await this.$confirm("文件夹创建成功", createDirResponseData.getBaseresp().getMessage())

            } else {
                await this.getDirHandler();
                await this.$confirm("文件夹创建失败", createDirResponseData.getBaseresp().getMessage())
            }
            this.createDirForm.dirName = ""
        }
        ,
        getContent: async function (nodeId) {
            if (nodeId === -1) return
            let getNodeRequest = new protoGetNode.GetNodeRequest();
            getNodeRequest.setNodeid(nodeId);
            // console.log("nodeId", nodeId)
            let token = this.$cookies.get("token");
            let baseReq = new protoCommon.BaseReq();
            baseReq.setToken(token);
            getNodeRequest.setBasereq(baseReq);

            let getNodeResponse = await getNodeRemote(getNodeRequest.serializeBinary())
            let getNodeResponseAB = await getNodeResponse.data.arrayBuffer()
            const getNodeResponseData = new protoGetNode.GetNodeResponse.deserializeBinary(new Uint8Array(getNodeResponseAB))
            let node = getNodeResponseData.getNode();
            // console.log("node", node)
            // 如果不转化为对象，那么这里的到就是uint8Array,但是转换为对象的话，和数据库中存储的信息又对不上
            let nodeContent = arrayBufferToString(node.getNodecontent()); // base64String，用utf8解码的base64字符串
            let secretKey = arrayBufferToString(node.getSecretkey()); // base64String，用utf8解码的base64字符串，但传过来的时候都自动进行了编码
            // console.log(secretKey)
            if (secretKey === undefined || secretKey === "") {
                // 说明文件被删除，就只能显示源文件被删除了,弹出弹窗，就结束了，后面可以让用户选择是否留存
                // await this.$confirm("文件已被删除", createDirResponseData.getBaseresp().getMessage())
                await this.$confirm("源文件文件已被删除，无法查看", "failed")
                this.shareForm.shareFileKey = ""
                return
            }

            let encryptedContentAB = base64ToArrayBuffer(nodeContent)
            let encryptedSecretKeyAB = base64ToArrayBuffer(secretKey)

            let key2 = base64ToArrayBuffer(this.$cookies.get("key2"))

            let secretKeyAB = decryptByAES256(encryptedSecretKeyAB, key2, this.$store.state.iv)

            let contentAB = decryptByAES256(encryptedContentAB, secretKeyAB, this.$store.state.iv)

            this.shareForm.shareFileKey = arrayBufferToBase64(secretKeyAB)
            this.showContent = arrayBufferToString(contentAB);

        }
        ,
        searchFileHandler: async function (keyword) {
            this.loading = true
            if (keyword !== "") {
                // console.log(keyword, "begin")
                // let begin = Date.now()
                this.options = []
                // 搜索令牌生成
                let lastId = this.$store.getters["user/getLastId"]
                let key1 = base64ToArrayBuffer(this.$cookies.get("key1"))
                let key2 = base64ToArrayBuffer(this.$cookies.get("key2"))

                let idString = lastId.get(keyword)

                if (idString === undefined) {
                    // this.options = []
                    this.loading = false
                    return
                }
                let idAB = stringToArrayBuffer(idString)
                let wAB = stringToArrayBuffer(keyword)
                let w_id = merge(wAB, idAB)

                let L = HmacSHA256(key1, w_id)
                let Jw = HmacSHA256(key2, w_id)

                let searchToken = new protoSendSearchToken.SearchToken()

                searchToken.setL(arrayBufferToBase64(L));
                searchToken.setJw(arrayBufferToBase64(Jw));

                let sendSearchTokenRequest = new protoSendSearchToken.SendSearchTokenRequest()
                let token = this.$cookies.get("token");
                let baseReq = new protoCommon.BaseReq();
                baseReq.setToken(token);
                sendSearchTokenRequest.setBasereq(baseReq);
                // console.log("test2", searchToken)
                sendSearchTokenRequest.setSearchtoken(searchToken)

                let sendSearchTokenResponse = await sendSearchToken(sendSearchTokenRequest.serializeBinary())

                let sendSearchTokenResponseAB = await sendSearchTokenResponse.data.arrayBuffer()
                const sendSearchTokenResponseData = new protoSendSearchToken.SendSearchTokenResponse.deserializeBinary(new Uint8Array(sendSearchTokenResponseAB))

                let cwsList = sendSearchTokenResponseData.getCwList();

                if (cwsList === [] || cwsList === undefined) {
                    // this.options = []
                    this.loading = false
                    return
                }
                let idList = []

                let kw = HmacSHA256(key2, wAB)
                // 解密文件id密文集合
                cwsList.map(
                    (cw) => {
                        let cwAB = base64ToArrayBuffer(cw)
                        // AES256解密函数
                        let idAB = decryptByAES256(cwAB, kw,
                            this.$store.state.iv)
                        idList.push(arrayBufferToString(idAB))
                    }
                )
                let searchFileRequest = new protoSearchFile.SearchFileRequest();
                searchFileRequest.setNodeidList(idList);
                baseReq.setToken(token);
                searchFileRequest.setBasereq(baseReq);

                let searchFileResponse = await searchFile(searchFileRequest.serializeBinary())
                let searchFileResponseAB = await searchFileResponse.data.arrayBuffer()

                const searchFileResponseData = new protoSearchFile.SearchFileResponse.deserializeBinary(new Uint8Array(searchFileResponseAB))
                const nodes = searchFileResponseData.getNodelistList();
                // this.options = []
                nodes.map(
                    (node) => {
                        this.options.push(node.toObject())
                        // console.log("options", node.toObject())
                    }
                )
                console.log(this.options.length)
                this.loading = false
            } else {
                this.options = []
                this.loading = false
            }
        },
        showDetail: async function () {
            await this.getContent(this.keyword);
            this.dialogVisible = true
            this.keyword = ""
            this.options = []
        },
        deleteFileOrDirHandler: async function (nodeId, nodeType) {
            let deleteFileRequest = new protoDeleteFile.DeleteFileRequest()

            // 先根据结点类型，判断是否需要从服务器上获取下面的子节点
            let dirQueue = []
            let nodeDeleteList = []
            console.log("nodeType", nodeType)
            if (nodeType === 2) {
                dirQueue.push(nodeId)
            }
            nodeDeleteList.push(nodeId)
            while (dirQueue.length > 0) {
                let curNodeId = dirQueue.shift();
                console.log("length", dirQueue.length)
                let nodes = await this.getDirInfo(curNodeId)
                nodes.map(
                    (node) => {
                        nodeDeleteList.push(node.getNodeid())
                        if (node.getNodetype() === 2) {
                            dirQueue.push(node.getNodeid())
                        }
                    }
                )
            }

            deleteFileRequest.setDelnodeidList(nodeDeleteList)

            let token = this.$cookies.get("token");
            let baseReq = new protoCommon.BaseReq();
            baseReq.setToken(token);
            deleteFileRequest.setBasereq(baseReq);

            let deleteFileResponse = await deleteFile(deleteFileRequest.serializeBinary())
            let deleteFileResponseAB = await deleteFileResponse.data.arrayBuffer()

            const deleteFileResponseData = new protoDeleteFile.DeleteFileResponse.deserializeBinary(new Uint8Array(deleteFileResponseAB))


            if (deleteFileResponseData.getBaseresp().getStatuscode() === protoCommon.StatusCode.SUCCESS) {
                await this.getDirHandler();
                if (nodeType === 2) {
                    await this.$confirm("文件夹删除成功", deleteFileResponseData.getBaseresp().getMessage())
                } else {
                    await this.$confirm("文件删除成功", deleteFileResponseData.getBaseresp().getMessage())
                }
            } else {
                await this.$confirm("删除失败", deleteFileResponseData.getBaseresp().getMessage())
            }
        },
        shareSingleFile: async function (nodeId, nodeName) {
            this.shareForm.shareFileId = nodeId;
            this.shareForm.shareFileName = nodeName;

            await this.getContent(nodeId) // 因此显示文件内容的弹窗就不能够放在getContent中
            this.sharedialogVisible = true
        },
        // sharePatchFile: async function (dirId, dirName) {
        sharePatchFile: async function () {
            await this.$confirm("功能尚未实现", "sorry")
            // this.sharedialogVisible = true
        },
        uploadShareTokenHandler: async function (form) {
            if (form.shareFileKey === "" || form.shareFileKey === undefined) {
                return
            }
            if (form.receiveName === "" || form.receiveName === undefined) {
                return
            }
            if (form.shareFileId === "" || form.shareFileId === undefined) {
                return
            }
            if (form.shareFileName === "" || form.shareFileName === undefined) {
                return
            }
            let uploadShareTokenRequest = new protoUploadShareToken.UpLoadShareTokenRequest();
            let shareToken = new protoCommon.ShareToken();
            let ownerName = this.$cookies.get("username");
            let userName = form.receiveName;
            let nodeId = form.shareFileId;
            let nodeName = form.shareFileName
            let secretKey = form.shareFileKey;
            // console.log("isShare", typeof this.shareForm.isShare)
            let key1AB = base64ToArrayBuffer(this.$cookies.get("key1"))
            let key2AB = base64ToArrayBuffer(this.$cookies.get("key2"))

            let lastW = this.$store.getters["user/getLastW"]

            let oldW = lastW.get(String(nodeId))

            if (oldW === undefined) {
                return;
            }

            let idAB = stringToArrayBuffer(String(nodeId))
            let wAB = stringToArrayBuffer(oldW)

            let w_id = merge(wAB, idAB)
            let id_w = merge(idAB, wAB)

            let L = HmacSHA256(key1AB, w_id)
            let Jid = HmacSHA256(key2AB, id_w)
            let kid = HmacSHA256(key2AB, idAB)

            shareToken.setL(arrayBufferToBase64(L))
            shareToken.setJid(arrayBufferToBase64(Jid))
            shareToken.setKid(arrayBufferToBase64(kid))
            shareToken.setFileid(String(nodeId))
            shareToken.setOwnerid(ownerName)
            shareToken.setUserid(userName)
            console.log("shareToken", shareToken)
            uploadShareTokenRequest.setSharetoken(shareToken)
            uploadShareTokenRequest.setFilename(nodeName)
            uploadShareTokenRequest.setSecretkey(secretKey)
            uploadShareTokenRequest.setIsshare(this.shareForm.isShare)
            let token = this.$cookies.get("token");
            let baseReq = new protoCommon.BaseReq();
            baseReq.setToken(token);
            uploadShareTokenRequest.setBasereq(baseReq);

            let uploadShareTokenResponse = await uploadShareToken(uploadShareTokenRequest.serializeBinary());
            let uploadShareTokenResponseAB = await uploadShareTokenResponse.data.arrayBuffer()
            const uploadShareTokenResponseData = new protoUploadShareToken.UpLoadShareTokenResponse.deserializeBinary(new Uint8Array(uploadShareTokenResponseAB))

            if (uploadShareTokenResponseData.getBaseresp().getStatuscode() === protoCommon.StatusCode.SUCCESS) {
                await this.getDirHandler();
                await this.$confirm("令牌上传成功", uploadShareTokenResponseData.getBaseresp().getMessage())
            } else {
                await this.$confirm("令牌上传失败", uploadShareTokenResponseData.getBaseresp().getMessage())
            }
            this.shareForm.shareFileName = ""
            this.shareForm.receiveName = ""
            this.shareForm.shareFileKey = ""
            this.shareForm.shareFileId = ""
            this.shareForm.isShare = '1'
        },
        getShareTokensHandler: async function () {
            let getShareTokensRequest = new protoGetShareTokens.GetShareTokensRequest()

            getShareTokensRequest.setUserid(this.$cookies.get("username"));

            let token = this.$cookies.get("token");
            let baseReq = new protoCommon.BaseReq();
            baseReq.setToken(token);
            getShareTokensRequest.setBasereq(baseReq);

            let getShareTokensResponse = await getShareTokens(getShareTokensRequest.serializeBinary())
            let getShareTokensResponseAB = await getShareTokensResponse.data.arrayBuffer();
            const uploadShareTokenResponseData = new protoGetShareTokens.GetShareTokensResponse.deserializeBinary(new Uint8Array(getShareTokensResponseAB))

            let shareTokenList = uploadShareTokenResponseData.getSharemesssagesList()

            this.shareTokenList = []

            shareTokenList.map(
                (shareToken) => {
                    let obj = shareToken.toObject();
                    // console.log("obj.isshare", obj.isshare, obj.isshare === "'1'")
                    if (obj.isshare === '1') {
                        obj.isshare = '分享'
                    } else {
                        obj.isshare = '转存'
                    }
                    // this.shareTokenList.push(shareToken.toObject())
                    this.shareTokenList.push(obj)
                    // console.log(shareToken.toObject())
                    // console.log(obj)

                }
            )
        },
        receiveShareTokenHandler: async function (L, Jid, Kid, secretKey, fileName, address, shareTokenId, isShare) {
            // 根据相关的消息，请求shareFirst，shareSecond，同时要注意存储的位置

            let nodeId = await this.getNodeId();
            let key1 = base64ToArrayBuffer(this.$cookies.get("key1"))
            let key2 = base64ToArrayBuffer(this.$cookies.get("key2"))

            let cidList = await this.shareFirst(L, Jid)
            let searchIndexList = []

            cidList.map(
                (cid) => {
                    console.log("cid", cid)
                    let cidAB = base64ToArrayBuffer(cid)
                    let wAB = decryptByAES256(cidAB, base64ToArrayBuffer(Kid), this.$store.state.iv)
                    console.log("wAB", arrayBufferToString(wAB))
                    let w = arrayBufferToString(wAB)
                    searchIndexList.push(this.searchIndexGen(nodeId, w, key1, key2))
                    console.log("cid", cid, 'word', w)
                }
            )
            let secretKeyAB = base64ToArrayBuffer(secretKey)

            let encryptedSecretKey = encryptByAES256(secretKeyAB, key2, this.$store.state.iv)

            let shareSecondRequest = new protoShareSecond.ShareSecondRequest()

            let token = this.$cookies.get("token");
            let baseReq = new protoCommon.BaseReq();
            baseReq.setToken(token);
            shareSecondRequest.setBasereq(baseReq);

            let biIndex = this.$store.getters["user/getBiIndex"]
            shareSecondRequest.setFilename(fileName)
            shareSecondRequest.setParentid(this.parentId)
            shareSecondRequest.setBiindex(arrayBufferToBase64(stringToArrayBuffer(biIndex)))
            shareSecondRequest.setNodeid(nodeId)
            shareSecondRequest.setIsshare(isShare === '分享')
            shareSecondRequest.setAddress(Number(address))
            shareSecondRequest.setFilesecret(arrayBufferToBase64(encryptedSecretKey))
            shareSecondRequest.setSearchindexsecondList(searchIndexList)
            console.log("shareSecond", shareSecondRequest)

            let shareSecondResponse = await shareSecondWithServer(shareSecondRequest.serializeBinary())
            let shareSecondResponseAB = await shareSecondResponse.data.arrayBuffer();
            const shareSecondResponseData = new protoShareSecond.ShareSecondResponse.deserializeBinary(new Uint8Array(shareSecondResponseAB))

            if (shareSecondResponseData.getBaseresp().getStatuscode() === protoCommon.StatusCode.SUCCESS) {
                await this.getDirHandler();
                await this.deleteShareToken(shareTokenId)
                await this.$confirm("文件接收成功", shareSecondResponseData.getBaseresp().getMessage())
            } else {
                await this.$confirm("文件接收失败", shareSecondResponseData.getBaseresp().getMessage())
            }

        },
        shareFirst: async function (L, Jid) {
            let shareFirstRequest = new protoShareFirst.ShareFirstRequest()

            shareFirstRequest.setL(L);
            shareFirstRequest.setJid(Jid)

            let token = this.$cookies.get("token");
            let baseReq = new protoCommon.BaseReq();
            baseReq.setToken(token);
            shareFirstRequest.setBasereq(baseReq);

            let shareFirstResponse = await shareFirstWithServer(shareFirstRequest.serializeBinary())
            let shareFirstResponseAB = await shareFirstResponse.data.arrayBuffer();
            const shareFirstResponseData = new protoShareFirst.ShareFirstResponse.deserializeBinary(new Uint8Array(shareFirstResponseAB))

            let cidList = []

            let s = shareFirstResponseData.getSList()
            s.map(
                (cid) => {
                    cidList.push(cid)
                }
            )
            return cidList
        },
        deleteShareToken: async function (shareTokenId) {
            let deleteShareTokenRequest = new protoDeleteShareToken.DeleteShareTokenRequest();

            deleteShareTokenRequest.setSharetokenid(shareTokenId)

            let token = this.$cookies.get("token");
            let baseReq = new protoCommon.BaseReq();
            baseReq.setToken(token);
            deleteShareTokenRequest.setBasereq(baseReq);

            let deleteShareTokenResponse = await deleteShareToken(deleteShareTokenRequest.serializeBinary())
            let deleteShareTokenResponseAB = await deleteShareTokenResponse.data.arrayBuffer();
            const deleteShareTokenResponseData = new protoDeleteShareToken.DeleteShareTokenResponse.deserializeBinary(new Uint8Array(deleteShareTokenResponseAB))

            if (deleteShareTokenResponseData.getBaseresp().getStatuscode() === protoCommon.StatusCode.SUCCESS) {
                console.log("删除已接收的shareToken成功")
            } else {
                console.log("删除已接收的shareToken失败")
            }
        },
        FileAndDirSort() {
            let fileList = []
            let dirList = []
            for (let i = 0; i < this.fileList.length; i++) {
                if (this.fileList[i].nodetype === 1) {
                    fileList.push(this.fileList[i])
                } else {
                    dirList.push(this.fileList[i])
                }
            }
            this.fileList = [...dirList, ...fileList]
        },
        fileShareClose(done) {
            this.shareForm.isShare = '1'
            this.shareForm.shareFileKey = ''
            this.shareForm.shareFileName = ''
            this.shareForm.shareFileId = ''
            this.shareForm.receiveName = ''
            done()
        },
        // uploadTest: async function (file = getRandomFile(1024 * 128)) {
        //     console.log("len", file.length)
        //     let total = 0;
        //     for (let i = 0; i < 10; i++) {
        //         let uploadFileRequest = new protoUploadFile.UploadFileRequest()
        //
        //
        //         // this.upload_content = e.target.result; // 直接获取文本文件的
        //         // 1kB 1024Base 1024*6/8
        //         // let file = str
        //         let fileSecret = getRandomBytes(32);
        //         let fileName = "text-" + i + ".txt";
        //
        //         let begin = Date.now()
        //         let cipherText = arrayBufferToBase64(encryptByAES256(stringToArrayBuffer(file), fileSecret, this.$store.state.iv));
        //
        //         let encryptedFileSecret = arrayBufferToBase64(encryptByAES256(fileSecret, base64ToArrayBuffer(this.$cookies.get("key2")), this.$store.state.iv))
        //
        //         if (cipherText.length === 0) {
        //             cipherText = ""
        //         }
        //         let nodeId = await this.getNodeId()
        //         // console.log("getNodeId", String(nodeId))
        //         let key1 = base64ToArrayBuffer(this.$cookies.get("key1"))
        //         let key2 = base64ToArrayBuffer(this.$cookies.get("key2"))
        //         // let begin = Date.now()
        //         let indexList = this.indexList(file, nodeId, key1, key2)
        //
        //         let biIndex = this.$store.getters["user/getBiIndex"]
        //
        //         let token = this.$cookies.get("token");
        //         let baseReq = new protoCommon.BaseReq();
        //         baseReq.setToken(token);
        //         uploadFileRequest.setBasereq(baseReq);
        //
        //
        //         uploadFileRequest.setFilename(fileName)
        //         uploadFileRequest.setParentid(this.parentId)
        //         uploadFileRequest.setIndexlistList(indexList)
        //         uploadFileRequest.setContent(new Uint8Array(stringToArrayBuffer(cipherText)))
        //         uploadFileRequest.setBiindex(arrayBufferToBase64(stringToArrayBuffer(biIndex)))
        //         uploadFileRequest.setNodeid(Number(nodeId));
        //         uploadFileRequest.setFilesecret(encryptedFileSecret);
        //         let uploadFileResponse = await uploadFile(uploadFileRequest.serializeBinary())
        //         let uploadFileResponseAB = await uploadFileResponse.data.arrayBuffer()
        //         const uploadFileResponseData = new protoUploadFile.UploadFileReponse.deserializeBinary(new Uint8Array(uploadFileResponseAB))
        //         if (uploadFileResponseData.getBaseresp().getStatuscode() === protoCommon.StatusCode.SUCCESS) {
        //             // await this.getDirHandler();
        //             // await this.$confirm("上传成功", uploadFileResponseData.getBaseresp().getMessage())
        //             console.log(i);
        //         }
        //         total += Date.now() - begin
        //         // console.log(i)
        //     }
        //     console.log("10", total / 10)
        // },
        // searchFileTest: async function () {
        //     await this.uploadTest("test1 test2")
        //     await this.uploadTest("test3 test2")
        //     let total = 0;
        //     for (let i = 0; i < 300; i++) {
        //         let begin = Date.now()
        //         await this.searchFileHandler("test1")
        //         total += Date.now() - begin
        //     }
        //     console.log("test1", total / 300)
        //     total = 0;
        //     for (let i = 0; i < 300; i++) {
        //         let begin = Date.now()
        //         await this.searchFileHandler("test2")
        //         total += Date.now() - begin
        //     }
        //     console.log("test2", total / 300)
        // }
    }

}
</script>

<style lang="stylus" scoped>
@import '~@/assets/styles/varibles.styl'
@import '~@/assets/styles/mixins.styl'
.file-wrapper {
  height: 500px;
  padding: 0 20px;
  display: flex;
  flex-direction: column;
  margin: 0 auto;

}

.tools {

}

.refresh-button {
  height: 50px;
  margin: 0 auto;
  box-pack: center;
}

.upload-button {
  height: 50px;
  margin: 0 auto;
  box-pack: center;
}

.search-button {
  height: 50px;
  margin: 0 auto;
  box-pack: center;
}

.showFileList {
  margin: 0 auto;
}


</style>